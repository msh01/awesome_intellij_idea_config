#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
/**
 * ${DESCRIPTION}
 * @author ${USER}
 * @date ${DATE} ${TIME}.
 */
public @interface ${NAME} {
}
