#set($TYPE = "自定义JS") 
/**
 * ${DESCRIPTION}(${TYPE})
 * @author ${USER}
 * @date ${DATE} ${TIME}.
 */
