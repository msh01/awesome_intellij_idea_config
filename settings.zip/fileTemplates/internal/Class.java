#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#set($TYPE = "业务实现") 
/**
 * ${DESCRIPTION}(${TYPE})
 * @author ${USER}
 * @date ${DATE} ${TIME}.
 */
public class ${NAME} {
}
