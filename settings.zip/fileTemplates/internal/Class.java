#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#set($TYPE = "业务实现")
#parse("File Header.java") 
public class ${NAME} {
}
