#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#set($TYPE = "枚举类型定义") 
/**
 * ${DESCRIPTION} ${TYPE}
 * @author ${USER}
 * @date ${DATE} ${TIME}.
 */
public enum ${NAME} {
}
