#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#set($TYPE = "接口定义") 
/**
 * ${DESCRIPTION}(${TYPE})
 * @author ${USER}
 * @date ${DATE} ${TIME}.
 */
public interface ${NAME} {
}
